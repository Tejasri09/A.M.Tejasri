package lab;
import java.util.*;
public class Sorted {
	public int[] getSorted(int a[])
	{
		int i,j,m,n,k;
		n=a.length;
		k=n-1;
		int b[]=new int[n];
		for(i=0;i<n;i++)
			b[k--]=a[i];
		for(i=0;i<n;i++)
		{
			for(j=0;j<n;j++)
			{
				if(b[i]<b[j])
				{
					m=b[i];
					b[i]=b[j];
					b[j]=m;
				}
			}
		}
		return b;
		}
	    public static void main(String[] args) 
	    { 
	       Scanner sc=new Scanner(System.in);
	       System.out.println("Enter the array:");
	       int n=sc.nextInt();
	       int a[]=new int[n];
	       int i;
	       System.out.println( "enter " +n+ " elements in the array");
	       for(i=0;i<n;i++)
	    	a[i]=sc.nextInt();
	       	Sorted sorted=new Sorted();
	       	int c[]=sorted.getSorted(a);
	       	for(i=0;i<n;i++)
	       	System.out.println(c[i]);
	    } 
}
