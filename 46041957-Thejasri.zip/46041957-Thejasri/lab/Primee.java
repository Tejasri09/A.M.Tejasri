package lab;
import java.util.*;
public class Primee
{
		public static void main (String args[]) { 
			Scanner sc=new Scanner(System.in);
			int n;int p=0;
			n=sc.nextInt();
			sc.close();
			for(int i=2;i<n;i++)
			{
				for(int j=2;j<i;j++)
				{
					if(i%j==0)
					p=1;
					if(p==0)
				{
					System.out.println(i);
				}
				}
		}
		}
	}
