package lab;
import java.util.Scanner;
public class Validate {
	public static void main(String[] args)
	{
		Scanner s = new Scanner(System.in);
		System.out.print("Enter ur first name: ");
		String firstName = s.nextLine();
		System.out.println("Enter ur last name: ");
		String lastName = s.nextLine();
		try
		{
			if(firstName.length()==0 &&  lastName.length()==0) 
			{
				throw new NameException("please fill first name and last name");
			}
			else
			{
				System.out.println("Successfully writtern");
			}
		}
		catch (NameException a)
		{
			System.out.println(a);
		}
		s.close();
	 }
}
class NameException extends Exception
{
	  public NameException(String str)
	  {
		  System.out.println(str);
	  }
}
