package lab;
import java.util.*;
public class Check {
	public boolean checkNumber(int n) {
		int i=1;
		while(true)
		{
			i=i*2;
			if(i==n)
			{
				return true;
			}
			else if(i>n)
			{
				return false;
			}
		}
	}
public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
	int n=sc.nextInt();
	Check t=new Check();
	boolean x =t.checkNumber(n);
	System.out.println(x);
	sc.close();
}
}
