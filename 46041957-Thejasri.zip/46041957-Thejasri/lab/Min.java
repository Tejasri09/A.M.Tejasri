package lab;
	import java.util.Arrays;
	import java.util.Scanner;
	public class Min
	{
		public int getSecondSmallest(int a[]) {
			Arrays.sort(a);
			return a[1];
		}
	    public static void main(String[] args) 
	    {
	    	Scanner sc = new Scanner(System.in);
	        System.out.print("Enter no. of elements in array:");
	        int num = sc.nextInt();
			int a[] = new int[num];
	        System.out.println("Enter elements:");
	        sc.close();
	        for(int i = 0; i < num; i++)
	        {
	            a[i] = sc.nextInt();
	        }
	        Min secondSmallest=new Min();
	        System.out.println(secondSmallest.getSecondSmallest(a));
	    }
	}
