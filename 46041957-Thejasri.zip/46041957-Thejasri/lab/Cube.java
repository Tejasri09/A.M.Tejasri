package lab;
import java.util.*;

public class Cube {
		int sum = 0;
		public void sum(int n)
		{
			for( int x=1;n!=0 && x<=n;x++)
			{
				sum = sum+(x*x*x);
			}
			System.out.println(sum);
		}
		public static void main(String args[])
		{
			Scanner sc = new Scanner(System.in);
			int n = sc.nextInt();
			Cube ob = new Cube();
			ob.sum(n);
			sc.close();
		}
	}
