package lab;
import java.util.*;
public class Diff {
public int calculateDifference(int n) { 
	int y=0;
	int z=0;
	for(int i=0;i<n;i++)
	{
		int a=i*i;
		y=y+i;
		z=z+a;
	}
	int sum=y*y;
	int x = z-sum;
	return sum;
}
public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the number:");
	int n=sc.nextInt();
	Diff t=new Diff();
	System.out.println(t.calculateDifference(n));
	sc.close();
}
}