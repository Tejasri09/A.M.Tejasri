package lab;
import java.util.*;
public class Calc
{
	public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the value:");
	int n=sc.nextInt();int sum=0,i;
	sc.close();
	for(i=1;i<=n;i++)
	{
		if((i%3==0) || (i%5==0))
			sum+=i;
	}
	System.out.println(sum);
	}
	}
