package lab;
import java.util.ArrayList;
import java.util.List;

public class Array {
	public static void main(String args[]) 
	{
		
		List list=new ArrayList();// cretaing obj for list
		
		// adading elements in list
		list.add("first");
		list.add("second");
		list.add("third");
		list.add("4th");
		list.add(new Float(4.0f));
		list.add(new Integer(5));
		// it will be automatically wrapped into object in java 5
		list.add(7);
		
		System.out.println(list);
		
		
		
		
		}

}