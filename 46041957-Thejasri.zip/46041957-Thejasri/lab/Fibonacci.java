package lab;
import java.util.*;

public class Fibonacci {
		public void Fib(int n)
		{
			int a=1;
			int b=1;
			int i=2;
			int c=0;
			while(i!=n)
			{
				c = a+b;
				a = b;
				b = c;
				i++;
			}
			System.out.println(c);
		}
		public static void main(String args[])
		{
			Scanner sc = new Scanner(System.in);
			int n = sc.nextInt();
			sc.close();
			Fibonacci ob = new Fibonacci();
			ob.Fib(n);
		}
	}
